<?php
###################################SQL CONNECTION#############################################
	error_reporting(2);
	define("DBUSERNAME", "root",  true);
	define("DBPASSWORD", "" ,     true);
	define("DBHOST", "localhost", true);
	define("DBDATABASE", "payment",  true);
##############################################################################################
?>



