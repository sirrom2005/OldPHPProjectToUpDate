<?php
	unset($_SESSION['admin']); 
?>

<meta http-equiv="refresh" content="3;index.php" />
<p>&nbsp;</p>
<h4 align="center"><span class="output"><img src="../images/loading.gif"/> logging out please wait...</span></h4>
<p>&nbsp;</p>